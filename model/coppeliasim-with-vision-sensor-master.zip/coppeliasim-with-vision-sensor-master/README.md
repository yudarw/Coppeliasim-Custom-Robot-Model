### Coppeliasim with vision sensor

![Image](Image/ss.PNG)
